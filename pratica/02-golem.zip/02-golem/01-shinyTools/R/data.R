#' Meses do ano
#'
#' Objeto com os meses do ano em português.
#'
"meses"
